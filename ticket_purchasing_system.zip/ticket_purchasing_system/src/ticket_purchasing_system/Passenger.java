package ticket_purchasing_system;

import java.util.Random;

// Class representing a Passenger, implementing the Runnable interface
public class Passenger implements Runnable {

    private final TicketMachine machine;
    private final String passengerName;
    private String phoneNumber;
    private String emailAddress;
    private final String arrivalLocation;
    private final String departureLocation;

    Random random = new Random();

    // Constructor for creating a Passenger instance
    public Passenger(TicketMachine machine, String passengerName, String phoneNumber, String emailAddress,
                     String arrivalLocation, String departureLocation) {
        this.machine = machine;
        this.passengerName = passengerName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.arrivalLocation = arrivalLocation;
        this.departureLocation = departureLocation;
    }

    // Overriding the run method from the Runnable interface
    @Override
    public void run() {
        // Invoking the getTicket method of the associated TicketMachine with passenger details
        machine.getTicket(this.passengerName, this.phoneNumber, this.emailAddress, this.arrivalLocation,
                this.departureLocation);
        try {
            // random sleep time between 1000 and 2000 milliseconds
            Thread.sleep(random.nextInt(1000) + 1000);
        } catch (InterruptedException e) {
            // Throwing a RuntimeException if interrupted during sleep
            throw new RuntimeException(e);
        }
    }
}
