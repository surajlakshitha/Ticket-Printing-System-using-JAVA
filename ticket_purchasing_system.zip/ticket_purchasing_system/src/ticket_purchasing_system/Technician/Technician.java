package ticket_purchasing_system.Technician;

import ticket_purchasing_system.ServiceTicketMachine;

// Declaring an abstract class named Technician
public abstract class Technician {

    // Defining a constant for the number of retry attempts
    public static final int NUMBER_OF_RETRY = 3;

    // Declaring a variable of type ServiceTicketMachine to hold a reference to the service ticket machine
    public ServiceTicketMachine serviceTicketMachine;

    // Declaring a String variable to store the name of the technician
    public String name;
}
