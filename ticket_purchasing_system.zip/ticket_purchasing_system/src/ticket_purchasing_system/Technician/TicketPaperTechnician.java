package ticket_purchasing_system.Technician;

import ticket_purchasing_system.ServiceTicketMachine;
import ticket_purchasing_system.TicketMachine;

import java.util.Random;

// Concrete class TicketPaperTechnician extending the abstract class Technician and implementing the Runnable interface
public class TicketPaperTechnician extends Technician implements Runnable {

    // Creating a Random object for generating random sleep times
    Random random = new Random();

    // Constructor for TicketPaperTechnician, taking name and a reference to the ServiceTicketMachine
    public TicketPaperTechnician(String name, ServiceTicketMachine serviceTicketMachine) {
        this.name = name;
        this.serviceTicketMachine = serviceTicketMachine;
    }

    // Overriding the run method from the Runnable interface
    @Override
    public void run() {
        // Looping for a specified number of retry attempts
        for (int i = 0; i < NUMBER_OF_RETRY; i++) {
            // Checking if paper level is below the threshold, and refilling if needed
            if (serviceTicketMachine.getPaperLevel() < ServiceTicketMachine.SHEETS_PER_PACK) {
                serviceTicketMachine.refillTicketPaper();
            }
            try {
                // Introducing a random sleep time between 1000 and 2000 milliseconds
                Thread.sleep(random.nextInt(1000) + 1000);
            } catch (InterruptedException e) {
                break;
            }
        }
        System.out.println("Paper Technician thread has finished, number of packs of paper used: " +
                TicketMachine.refillPaperPacksCount);
    }

}
