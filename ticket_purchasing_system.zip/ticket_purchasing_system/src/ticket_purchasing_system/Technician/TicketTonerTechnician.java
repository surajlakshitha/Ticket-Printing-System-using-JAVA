package ticket_purchasing_system.Technician;

import ticket_purchasing_system.ServiceTicketMachine;
import ticket_purchasing_system.TicketMachine;

import java.util.Random;

// Concrete class TicketTonerTechnician extending the abstract class Technician and implementing the Runnable interface
public class TicketTonerTechnician extends Technician implements Runnable {

    // Constructor for TicketTonerTechnician, taking name and a reference to the ServiceTicketMachine
    public TicketTonerTechnician(String name, ServiceTicketMachine serviceTicketMachine) {
        this.name = name;
        this.serviceTicketMachine = serviceTicketMachine;
    }

    // Overriding the run method from the Runnable interface
    @Override
    public void run() {
        // Looping for a specified number of retry attempts
        for (int i = 0; i < NUMBER_OF_RETRY; i++) {
            // Checking if toner level is below the minimum threshold, and replacing the toner cartridge if needed
            if (serviceTicketMachine.getTonerLevel() < ServiceTicketMachine.MIN_TONER_LEVEL) {
                serviceTicketMachine.replaceTonerCartridge();
            }
            try {
                // random sleep time between 1000 and 2000 milliseconds
                Thread.sleep(new Random().nextInt(1000) + 1000);
            } catch (InterruptedException e) {
                break;
            }
        }
        System.out.println("Toner Technician thread has finished, number of toner cartridges used: "
                + TicketMachine.replaceTonerCartridgeCount);
    }
}
