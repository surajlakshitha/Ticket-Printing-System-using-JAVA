package ticket_purchasing_system;

import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

// Class representing a Ticket Machine implementing the ServiceTicketMachine interface
public class TicketMachine implements ServiceTicketMachine {

    private String ticketMachineName;
    private int currentPaperLevel;
    private int currentTonerLevel;
    private int numberOfTicketsSold;
    public static int replaceTonerCartridgeCount = 0;
    public static int refillPaperPacksCount = 0;

    // ReentrantLock and Conditions for synchronization(allows a thread to acquire the same lock multiple times
    // prevent deadlock situations )
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition haveTonerLevel = lock.newCondition();
    private final Condition havePaperLevel = lock.newCondition();
    private final Condition noResource = lock.newCondition();


    // Constructor for creating a TicketMachine instance with specified details
    public TicketMachine(String ticketMachineName, int currentPaperLevel, int currentTonerLevel) {
        this.ticketMachineName = ticketMachineName;
        this.currentPaperLevel = currentPaperLevel;
        this.currentTonerLevel = currentTonerLevel;
        this.numberOfTicketsSold = 0;
    }

    // Method for a passenger to get a ticket and print it
    public Ticket getTicket(String passengerName, String phoneNumber, String emailAddress, String arrivalLocation,
                            String departureLocation) {
        Ticket ticket = purchaseTicket(passengerName, phoneNumber, emailAddress, arrivalLocation, departureLocation);
        printTicket(ticket);
        System.out.println("Passenger " + ticket.getPassengerName() + " got " + ticket);
        return ticket;
    }

    // Method for a passenger to purchase a ticket
    @Override
    public Ticket purchaseTicket(String passengerName, String phoneNumber, String emailAddress, String arrivalLocation,
                                 String departureLocation) {
        lock.lock();
        try {
            // Creating a new ticket with incremented ticket number
            Ticket ticket = new Ticket(numberOfTicketsSold + 1, 1000,
                    passengerName, phoneNumber, emailAddress, arrivalLocation, departureLocation);
            numberOfTicketsSold++;
            System.out.println("Ticket number: " + ticket.getTicketNumber().toString() + " purchased by " +
                    Thread.currentThread().getName());
            // Signaling other threads that paper and toner levels might have changed
            havePaperLevel.signalAll();
            haveTonerLevel.signalAll();
            return ticket;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            lock.unlock();
        }
    }

    // Method for printing a ticket
    @Override
    public void printTicket(Ticket ticket) {
        lock.lock();
        try {
            // random sleep time between 1000 and 2000 milliseconds
            Thread.sleep(new Random().nextInt(1000) + 1000);
            // Waiting for sufficient paper and toner levels
            while (!(currentPaperLevel > 0) || !(currentTonerLevel > ServiceTicketMachine.MIN_TONER_LEVEL)) {
                System.out.println("Passenger: " + ticket.getPassengerName() + " waiting for " +
                        "ticket machine:" + ticketMachineName);
                noResource.await();
            }
            // Decreasing paper and toner levels after printing
            currentPaperLevel--;
            currentTonerLevel--;
            System.out.println("Ticket number: " + ticket.getTicketNumber().toString() + " printed by " +
                    Thread.currentThread().getName());
            // Signaling other threads that paper and toner levels might have changed
            havePaperLevel.signalAll();
            haveTonerLevel.signalAll();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            lock.unlock();
        }
    }

    // Method for a toner technician to replace the toner cartridge
    @Override
    public void replaceTonerCartridge() {
        lock.lock();
        try {
            // Waiting until toner level falls below the minimum threshold
            while (currentTonerLevel >= ServiceTicketMachine.MIN_TONER_LEVEL) {
                System.out.println("Current toner level is " + currentTonerLevel + " and toner refilling is not " +
                        "needed for the ticket machine: " + ticketMachineName);
                haveTonerLevel.await();
            }
            // Refilling toner and updating the count
            currentTonerLevel = ServiceTicketMachine.MAX_TONER_LEVEL;
            replaceTonerCartridgeCount++;
            System.out.println("Toner Technician refilled the toner of ticket machine: " + ticketMachineName);
            // Signaling other threads that paper and toner levels might have changed
            noResource.signalAll();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            lock.unlock();
        }
    }

    // Method for a paper technician to refill the ticket paper
    @Override
    public void refillTicketPaper() {
        lock.lock();
        try {
            // Waiting until there is enough space in the paper tray
            while ((currentPaperLevel + ServiceTicketMachine.SHEETS_PER_PACK) > ServiceTicketMachine.FULL_PAPER_TRAY) {
                System.out.println("Machine has enugh papaer and the paper technician is waiting to refill ticket " +
                        "machine " + ticketMachineName);
                havePaperLevel.await();
            }
            // Refilling paper and updating the count
            currentPaperLevel += ServiceTicketMachine.SHEETS_PER_PACK;
            refillPaperPacksCount++;
            System.out.println("Paper Technician refilled the paper of ticket machine: " + ticketMachineName);
            // Signaling other threads that paper and toner levels might have changed
            noResource.signalAll();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            lock.unlock();
        }
    }

    // Method to get the current paper level
    @Override
    public int getPaperLevel() {
        return currentPaperLevel;
    }

    // Method to get the current toner level
    @Override
    public int getTonerLevel() {
        return currentTonerLevel;
    }
}