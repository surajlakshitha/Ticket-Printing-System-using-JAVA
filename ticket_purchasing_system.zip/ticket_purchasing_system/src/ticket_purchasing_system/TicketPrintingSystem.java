package ticket_purchasing_system;

import ticket_purchasing_system.Technician.TicketPaperTechnician;
import ticket_purchasing_system.Technician.TicketTonerTechnician;

public class TicketPrintingSystem {

    // Class representing the main Ticket Printing System
    public static void main(String[] args) {

        // Creating a TicketMachine instance
        TicketMachine ticketMachine = new TicketMachine(" TicketMachine_1", 1, 2);

        // Creating Passenger instances
        Passenger passenger_1 = new Passenger(ticketMachine, "passenger_1", "0110000001",
                "passenger_1@gmail.com", "arrivalLocation_1", "departureLocation_1");

        Passenger passenger_2 = new Passenger(ticketMachine, "passenger_2", "0110000002",
                "passenger_2@gmail.com", "arrivalLocation_2", "departureLocation_2");

        Passenger passenger_3 = new Passenger(ticketMachine, "passenger_3", "0110000003",
                "passenger_3@gmail.com", "arrivalLocation_3", "departureLocation_3");

        Passenger passenger_4 = new Passenger(ticketMachine, "passenger_4", "0110000004",
                "passenger_4@gmail.com", "arrivalLocation_4", "departureLocation_4");

        // Creating Technician instances (Toner and Paper)
        TicketTonerTechnician ticketTonerTechnician = new TicketTonerTechnician("Toner_Technician", ticketMachine);
        TicketPaperTechnician ticketPaperTechnician = new TicketPaperTechnician("Paper_Technician", ticketMachine);

        // Creating ThreadGroups for passengers and technicians
        ThreadGroup threadGroupPassenger = new ThreadGroup("ThreadGroup_Passenger");
        ThreadGroup threadGroupTechnician = new ThreadGroup("ThreadGroup_Technician");

        // Creating Threads for technicians
        Thread tonerTechnicianThread = new Thread(threadGroupTechnician, ticketTonerTechnician, "Toner_Technician");
        Thread paperTechnicianThread = new Thread(threadGroupTechnician, ticketPaperTechnician, "Paper_Technician");

        // Creating Threads for passengers
        Thread passengerThread_1 = new Thread(threadGroupPassenger, passenger_1, "passengerThread_1");
        Thread passengerThread_2 = new Thread(threadGroupPassenger, passenger_2, "passengerThread_2");
        Thread passengerThread_3 = new Thread(threadGroupPassenger, passenger_3, "passengerThread_3");
        Thread passengerThread_4 = new Thread(threadGroupPassenger, passenger_4, "passengerThread_4");

        // Starting passenger and technician threads
        passengerThread_1.start();
        passengerThread_2.start();
        passengerThread_3.start();
        passengerThread_4.start();

        tonerTechnicianThread.start();
        paperTechnicianThread.start();

        // Setting the maximum priority for the technician thread group
        threadGroupTechnician.setMaxPriority(Thread.MAX_PRIORITY);

        // Waiting for threads to finish
        while (threadGroupTechnician.activeCount() > 0 || threadGroupPassenger.activeCount() > 0) {
            if (threadGroupPassenger.activeCount() == 0) {
                // Interrupting technician threads if passengers have all finished
                threadGroupTechnician.interrupt();
                System.out.println("The technicians and passengers have all finished...");
                break;
            }
        }
    }
}