package ticket_purchasing_system;

// Interface defining the service contract for a Ticket Machine
public interface ServiceTicketMachine {

    // Constants representing the maximum number of sheets in a full paper tray, sheets per pack, maximum and minimum toner levels
    int FULL_PAPER_TRAY = 20;
    int SHEETS_PER_PACK = 5;
    int MAX_TONER_LEVEL = 15;
    int MIN_TONER_LEVEL = 10;

    // Method to print a ticket, taking a Ticket object as a parameter
    void printTicket(Ticket ticket);

    // Method to purchase a ticket, taking passenger details and locations as parameters and returning a Ticket object
    Ticket purchaseTicket(String passengerName, String phoneNumber, String emailAddress, String arrivalLocation,
                          String departureLocation);

    // Method to replace the toner cartridge
    void replaceTonerCartridge();

    // Method to refill the ticket paper
    void refillTicketPaper();

    // Method to get the current paper level
    int getPaperLevel();

    // Method to get the current toner level
    int getTonerLevel();
}
