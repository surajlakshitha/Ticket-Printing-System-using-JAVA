package ticket_purchasing_system;

public class Ticket {

    // Private fields representing ticket details
    private final Integer ticketNumber;
    private final float ticketPrice;
    private final String passengerName;
    private String phoneNumber;
    private String emailAddress;
    private final String arrivalLocation;
    private final String departureLocation;

    // Constructor for creating a Ticket instance with specified details
    public Ticket(int ticketNumber, float ticketPrice, String passengerName, String phoneNumber, String emailAddress,
                  String arrivalLocation, String departureLocation) {
        this.ticketNumber = ticketNumber;
        this.ticketPrice = ticketPrice;
        this.passengerName = passengerName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.arrivalLocation = arrivalLocation;
        this.departureLocation = departureLocation;
    }

    // Getter method for retrieving the ticket number
    public Integer getTicketNumber() {
        return ticketNumber;
    }

    // Getter method for retrieving the ticket price
    public float getTicketPrice() {
        return ticketPrice;
    }

    // Getter method for retrieving the passenger name
    public String getPassengerName() {
        return passengerName;
    }

    // Getter method for retrieving the phone number
    public String getPhoneNumber() {
        return phoneNumber;
    }

    // Setter method for updating the phone number
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // Getter method for retrieving the email address
    public String getEmailAddress() {
        return emailAddress;
    }

    // Setter method for updating the email address
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    // Getter method for retrieving the arrival location
    public String getArrivalLocation() {
        return arrivalLocation;
    }

    // Getter method for retrieving the departure location
    public String getDepartureLocation() {
        return departureLocation;
    }

    // Override of the toString method for creating a string representation of the Ticket object
    @Override
    public String toString() {
        return "Ticket{" +
                "ticketNumber=" + ticketNumber +
                ", ticketPrice=" + ticketPrice +
                ", passengerName='" + passengerName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", arrivalLocation='" + arrivalLocation + '\'' +
                ", departureLocation='" + departureLocation + '\'' +
                '}';
    }
}
